//textboxvariables
var textboxIn;
var textboxOut;
var slider;
var paragraph;

//KEY VARIABLES
//Command VARIABLES

var PMLeft_targetTemp = 200; //Results in Slider of same name once called in setup()
//These Two are the Actual sliders that the user slides. The other two just animate the system's progress towards the Target Temp.
var PMRight_targetTemp = 200;

var PMLeft_targetProgress = 200; //TODO These will be "overridden" by the Actual Temps coming in from the arduino. That is: User slides the TargetTemp_slider and then can see when the other slider catches up.
//TODO LATER swap the slider for a bar graph.
var PMRight_targetProgress = 200; //Same as above.

//BINARY COMMANDS
//===============
//..so instead we switch the gates individually like "swinging the points"
var ChimneyFanLeft_onOff = false;
var ChimneyFanRight_onOff = false;

//These fans below blow to cool whichever pipe we want to freeze up with plastic and block the flow.
//This could have been hard-coded in, but that would have messed with the "Machine Learning" aspects of this plastic to diesel plant.

//A short digression into Machine Learning:
//Heard a podcast, they were talking about the teams working on self-driving car. 
//What they do is rig the whole car with sensors enough sensors to be able to - for example - tell that he's now driving "uphill on a dirt road". Then when the automated car finds itself in the same terrain, it matches the actions of the human driver.

//How the above relates to P2D: How can we automate the diesel making-process if we are not yet sure ourselves what are the best actions to take at different junctures in the process? 

//instead, while we learn what are the best settings to make excellent Plastic to Diesel efficiently, we are datalogging all states and actions, plus timestamped Operator Notes.

//While we learn, the system learns.

//Back to the line-by-line comments for the code


//Boolean values become check-boxes. Boolean flags within, are a great way to control the program flow.
var GateLeftCooling_onOff = false;
var GateRightCooling_onOff = false;

//Boolean Commands are sent to the arduino as a single 8-bit byte of binary onOff signals.

//So far we only have four On/Off switches, but a single byte can hold 8-bits. We therefore have four spaces available in the single one-byte signal to use for future On/Off switches.
var bit5 = true; //these are placeholders for future On/Off switches 
var bit6 = false;
var bit7 = true;
var bit8 = false;

var compressedBinaryCommands = GateLeftCooling_onOff << 7 | GateRightCooling_onOff << 6 | ChimneyFanLeft_onOff << 5 | ChimneyFanRight_onOff << 4 | bit5 << 3 | bit6 << 2 | bit7 << 1 | bit8;

//var canvas = document.getElementById("canvas"),
//    context = canvas.getContext("2d"),
//    width = canvas.width = window.innerWidth,
//    height = canvas.height = window.innerHeight;


var PM_Left = {
    tempC: 50,
    targetTemp: 250,
    chimneyFan_on: true,
    coolingFan_off: true,
    text: "hello"
};

var PM_Right = {
    tempC: 49,
    targetTemp: 50,
    chimneyFan_on: false,
    coolingFan_off: false,
    text: "hello"
};

var Reactor_temp1 = 40;
var Reactor_temp2 = 40;
var updateButton;
var firstContact = true; //variable to receive first contact from Arduino. 
var serial;


function printList(portList) {
    // portList is an array of serial port names
    for (var i = 0; i < portList.length; i++) {
        // Display the list the console:
        console.log(i + " " + portList[i]);
    }
}

function serverConnected() {
    console.log('connected to server.');
}

function portOpen() {
    console.log('the serial port opened.')
}

function serialError(err) {
    console.log('Something went wrong with the serial port. ' + err);
}

function portClose() {
    console.log('The serial port closed.');
}


function sendOutput() {

    var messageToArduino = settings.getValue("Console");
    //not sure what to do here
    serial.writeln(messageToArduino);

    receiveEcho();

}


function logInput() {
    // if ()


}

function logOutput() {
    if (serial.available > 2) {
        var inString = serial.readStringUntil('\r\n');
        if (inString.startsWith('A') && (firstContact == false)) {
            serial.writeln(tempVarForBinaryAsInteger);
            console.clear();
            console.setValue(outputText, inString);

        } else if (inString.startsWith('T')) {
            var tempActuals = splitTokens(inString, ",");
            //expect something like 250, 50, 500 for PMLeft, PMRight, ReactorTemp
            print(tempActuals); // prints : ["Mango"," Banana"," Lime"]
        }


    }


}

//replaces the update button I was planning above this function is set as GlobalChangeHandler
//function update() {
//    logOutput();
//    //put a timer here
//    //counter++;
//    //if (counter = 10) && ()
//
//
//}
var textArea;
var inputText;
var outputText;
var deeConsole;
var arduinoMessage = "Nothing to Say Just Yet";

function doSomething() {
    console.log("doing something");
}

function doNothing() {
    console.log("doing nothing");
}

function setup() {

    createCanvas(640, 480); // make canvas
    smooth(); // antialias drawing lines
    serial = new p5.SerialPort(); // make a new instance of the serialport library
    //serial.on('list', printList); // set a callback function for the serialport list event
    serial.on('connected', serverConnected); // callback for connecting to the server
    serial.on('open', portOpen); // callback for the port opening
    serial.on('data', serialEvent); // callback for when new data arrives
    serial.on('error', serialError); // callback for errors
    serial.on('close', portClose); // callback for the port closing

    //serial.list(); // list the serial ports
    serial.open("COM3"); // open a serial port



    var panel4 = QuickSettings.create(730, 10, "Output Panel")
        .addTextArea("Output");


    function output(name, value) {
        panel4.setValue("Output", name + " : " + value);
    }


    deeConsole = QuickSettings.create(500, 500, "Console");
    textArea = deeConsole.addTextArea("Arduino says: ", "Arduino says: ", doNothing);


    textboxIn = createInput("enter text");
    // textboxIn.parent(deeConsole);//doesn't work, but Whyyyy

    textboxIn.mouseClicked(clearText);
    textboxIn.changed(updateText);
    slider = createSlider(10, 64, 16);
    paragraph = createP("starting text");

    slider.changed(updateSize);
    //slider.input(updateSize);
    //textboxIn.input(doSomething); not yet working due to editor issue (2015.10.24)



    //inputText = deeConsole.addText("Input console", "type response here", logOutput());
    //inputText.changed(doSomething);
    //outputText = deeConsole.addTextArea("Arduino Output console", "arduino says", logInput());
    //deeConsole.addButton("Enter Input");



    var PM_Left_settings = QuickSettings.create(10, 10, "Plastic Melting Left");
    //    PM_Left_settings.setGlobalChangeHandler(update);
    PM_Left_settings.bindRange("tempC", 0, 500, 50, 1, PM_Left);
    PM_Left_settings.addProgressBar("Temp C", 500, 250, PM_Left); // creates a progress bar
    PM_Left_settings.bindBoolean("chimneyFan_on", true, PM_Left);
    PM_Left_settings.bindBoolean("coolingFan_off", true, PM_Left);

    var PM_Right_settings = QuickSettings.create(400, 10, "Plastic Melting Right");
    //    PM_Right_settings.setGlobalChangeHandler(update);
    PM_Right_settings.bindRange("tempC", 0, 100, 50, 1, PM_Right);
    PM_Right_settings.addProgressBar("Temp C", 500, 250, PM_Right); // creates a progress bar
    //PM_Left_settings.addProgressBar("Temp C", max, value, valueDisplay);   // creates a progress bar
    PM_Right_settings.bindBoolean("chimneyFan_on", true, PM_Right);
    PM_Right_settings.bindBoolean("coolingFan_off", true, PM_Right);

    var Reactor_settings = QuickSettings.create(400, 10, "Reactor Status");
    Reactor_settings.addProgressBar("Temp One", 500, 250, Reactor_temp1); // creates a progress bar
    Reactor_settings.addProgressBar("Temp Two", 500, 250, Reactor_temp2); // creates a progress bar

    var button = createButton('Update settings to Hardware');
    button.position(250, 65);
    button.mousePressed(serialEvent);

}

function clearText() {
    textboxIn.value('');
}



function updateSize() {
    // paragraph.style("font-size", "24pt");
    paragraph.style("font-size", slider.value() + "pt");
}


function updateText() {

    serial.write(textboxIn.value());
    console.log("Input Received" + (textboxIn.value()));
}

function draw() {
    var locH, locV; // location of the circle
    var circleColor = 255; // color of the circle
    function draw() {
        background(0); // black background
        fill(circleColor); // fill depends on the button
        ellipse(locH, locV, 50, 50); // draw the circle
    }

}
//TODO fill out all the scenarios.
function serialEvent() {
    // read a string from the serial port
    // until you get carriage return and newline:
    var inString = serial.readStringUntil('\n');
    //check to see that there's actually a string there:

    if ((inString.charAt(0) == 'A') && (firstContact == true)) {
        serial.write('A23');
        serial.write('\n');
        firstContact = false;
        console.log('Made First Contact');
        console.log("Arduino says: " + inString);

    } else if (firstContact == false) {
        if ((inString.charAt(0)) == 'T') {
            var actualTempsArray = splitTokens(inString, "T,");

            print(actualTempsArray); // prints : ["Mango"," Banana"," Lime"]
        } else if ((inString.charAt(0)) == 'R') {
            var targetTempsArray = splitTokens(inString, "R,");

            print(targetTempsArray); // prints : ["Mango"," Banana"," Lime"]
        }



    }
    //; // send a byte requesting more serial data 

    //use after initial testing
    //else if inString.contains('A')
    arduinoMessage = inString;
    deeConsole.setText("Arduino says: ", "arduinoMessage");
}
